<?php

namespace App\Http\Controllers;

use App\Http\Requests\LaptopStoreRequest;
use App\Http\Requests\LaptopUpdateRequest;
use App\Models\Laptop;
use Illuminate\Http\Request;

class LaptopsController extends Controller
{

    public function index(){
        $laptops = Laptop::all();
        return view('laptop-list', compact('laptops'));
    }

    public function create(){
        return view('laptop-form');
    }

    public function store(Request $request){
        Laptop::create([
            "brand" => $request->brand,
            "model" => $request->model,
            "processor" => $request->processor,
            "ram" => $request->ram,
        ]);
        return redirect('/');
    }

    public function show(Laptop $laptop){
        //
    }

    public function edit(Laptop $laptop){
        return view('laptop-edit', compact('laptop'));
    }


    public function update(Request $request, Laptop $laptop){
        $laptop->update([
            "brand" => $request->brand,
            "model" => $request->model,
            "processor" => $request->processor,
            "ram" => $request->ram,
        ]);
        return redirect('/');

    }

    public function destroy(Laptop $laptop){
        $laptop->delete();
        return redirect('/');
    }
}

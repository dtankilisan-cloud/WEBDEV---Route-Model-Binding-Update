<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LaptopsController;

Route::get('/', [LaptopsController::class, 'index']);
Route::get('/create-laptop' , [LaptopsController::class, 'create']);
Route::post('/save-laptop' , [LaptopsController::class, 'store'])->name('save-laptop');
Route::post('/delete-laptop/{laptop}', [LaptopsController::class, 'destroy'])->name('delete-laptop');
Route::get('/edit-laptop/{laptop}', [LaptopsController::class, 'edit'])->name('edit-laptop');
Route::post('/update-laptop/{laptop}', [LaptopsController::class, 'update'])->name('update-laptop');